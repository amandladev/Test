import React, {useState} from 'react';
import { Link } from 'wouter';

import './Navbar.css'


function Navbar() {
 
  const [click, setClick] = useState(false);
  const handleClick = () => setClick(!click);
  const closeMobileMenu = () => setClick(false);
  const [navbar, setNavbar] = useState(false);

  const checkNavbar = () => {
    if (window.scrollY >= 100){
      setNavbar(true);
    }
    else{
      setNavbar(false)
    }
  }
  console.log(checkNavbar)
window.addEventListener('scroll', checkNavbar)

  return (
  <> 
  
  <nav className={navbar ? 'navwhitebackground' : 'navbar'}>
      <div className="navbar-container">
        <div className='navbar--logo'>
          <Link to='/' className={navbar ? 'navbar-logo logoblack' : 'navbar-logo'}  onClick={closeMobileMenu}>
                Bruno Tapia
          </Link>
          
          
        </div>
        <div className='menu-icon-bars' onClick={handleClick}>
            <i className={click ? 'fas fa-times' : 'fas fa-bars'} />
          </div>
        <ul className={click ? 'navbar--link active' : 'navbar--link'}>
          <li>
          <Link to='/' className={navbar ? 'navbar-link linkblack' : 'navbar-link'} onClick={closeMobileMenu}>
                  Cucine
            </Link>
            </li>
            <li>
            <Link to='/' className={navbar ? 'navbar-link linkblack' : 'navbar-link'} onClick={closeMobileMenu}>
                  Sistemi
            </Link>
            </li>
            <li>
            <Link to='/' className={navbar ? 'navbar-link linkblack' : 'navbar-link'} onClick={closeMobileMenu}>
                Azienda
            </Link>
            </li>
            <li>
            <Link to='/' className={navbar ? 'navbar-link linkblack' : 'navbar-link'} onClick={closeMobileMenu}>
                  Contact
            </Link>
            </li>
        </ul>
      </div>
  </nav>
  </>
  );
}

export default Navbar;
