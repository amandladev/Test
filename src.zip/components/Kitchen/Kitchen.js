import React from 'react';
import '../../App.css';
import './Kitchen.css';

function Kitchen() {
    return (
    
    <section className='video-container'>
        
        <video src='/videos/euromobilhome.mp4' autoPlay loop muted />
            
        <div className='text-left-container'> 
            <h1 className='text-left'>Kitchen <br></br> Atmosphere</h1>
        </div>
        <div className='spinner-left-container'>
            <div className='spinner-left'></div>
        </div>
    
    </section>      
)}
export default Kitchen