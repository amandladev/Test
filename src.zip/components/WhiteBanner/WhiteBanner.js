import React from 'react';
import './WhiteBanner.css';

export default function WhiteBanner(){ 
        return (
            <section className='uk-white-banner'>
                <div className='uk-grid'> 
                    <div className='item-uk-column'>
                        <div>
                            <h5 className='t-large'>GRUPPO EUROMOBIL E L'ARTE | Pablo Atchugarry. Vita della Materia</h5>
                            <p>Continua l’opera di mecenatismo di Gruppo Euromobil, cifra distintiva dell’amore per l'arte dei titolari, 
                                i fratelli Lucchetta. L’azienda è main sponsor della mostra iconografica Pablo Atchugarry “Vita della materia”.</p>
                        </div>
                        <span className='btn-txt'>Scopri di più</span>
                    </div>
                    <div className='item-uk-column'>
                        <div>
                            <h5 className='t-large'>GRUPPO EUROMOBIL E L'ARTE | Alberto Biasi. Tuffo nell’arcobaleno</h5>
                            <p>Gruppo Euromobil in veste di main sponsor, promuove la mostra di Alberto Biasi 
                                <em>Tuffo nell’arcobaleno</em>
                                in corso a Roma, presso il Museo dell’Ara Pacis, fino al 22 febbraio 2022.
                                </p>
                        </div>
                        <span className='btn-txt'>Scopri di più</span>
                    </div>
                    <div className='item-uk-column'>
                        <div>
                            <h5 className='t-large'>GRUPPO EUROMOBIL E L'ARTE | Omaggio a Virgilio Guidi</h5>
                            <p className='t-small'>Gruppo Euromobil, da sempre coinvolto attivamente a sostegno dell'arte, è main sponsor della mostra Omaggio a 
                            Virgilio Guidi con uno sguardo alla Collezione Sonino in corso a Venezia fino al 7 gennaio 2022.</p>
                        </div>
                        <span className='btn-txt'>Scopri di più</span>
                    </div>
                </div>
            </section>
        )
}