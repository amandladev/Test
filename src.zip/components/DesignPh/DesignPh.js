import React from 'react';
import './DesignPh.css';

function DesignPh() {
    return (
        <section className='design-container'>
            <div className='des-maxwidth'> 
                <div className='des-uk-grid'>
                    <div className='txt-uk'>
                        <div className='txt-height'>
                        <span className='normalfont'> il 
                            <span className='boldfont'>Design</span>
                        </span>
                        <br></br>
                        <span className='normalfont'> che 
                            <span className='boldfont'>Genera</span>
                        </span>
                        <br></br>
                        <span className='normalfont'> los 
                            <span className='boldfont'>Spazio</span>
                        </span>
                        </div>
                        <p> Kitchen systems and storage units become self-bearing architectural structures. 
                            Planning potential inspired not only by architecture and haute couture but most of all by art.</p>
                    </div>
                    <div className='img-container-de'>
                        <img src='/images/banner-cucine.jpg' alt='cucine'></img>
                        <h3 className='txt-middle'>Cucine</h3>
                    </div>

                </div>
               
            
                <div className='img-container-de item-uk1'>
                    <img src='/images/banner-azienda.jpg' alt='azienda'></img>
                    <h3 className='txt-middle'>Sistemi</h3>
                </div>
                <div className='img-container-de item-uk2'>
                    <img src='/images/banner-sistemi.jpg' alt='sistemi'></img>
                    <h3 className='txt-middle'>Azienda</h3>
                </div>
            </div>
        </section>
    )
}
export default DesignPh