import React from 'react';
import { Link } from 'wouter';
import './Footer.css';
export default function Footer (){
    return (
        <div className='footer'>
            <div>
               
                <div className='r2'>
                    <div className='social'>
                        <div>
                            <Link to='/' className='a-link'>
                                <img src='/images/facebook.svg'width='45' height='45' alt='Facebook' className='imgfooter'></img>
                            </Link>
                            <Link to='/' className='a-link'>
                                <img src='/images/linkedin.svg' width='45' height='45' alt='Linkedin'className='imgfooter'></img>
                            </Link>
                            <Link to='/' className='a-link'>
                                <img src='/images/instagram.svg' width='45' height='45' alt='Instagram' className='imgfooter'></img>
                            </Link>
                            <Link to='/' className='a-link'>
                                <img src='/images/youtube.svg' width='45' height='45' alt='Youtube' className='imgfooter'></img>
                            </Link>
                        </div>
                    </div>
                    <div className='credits'>
                        <span> website by SergioR</span>
                    </div>
                </div>
            </div>
        </div>
    )
}