import React from 'react';
import './BannerSec.css';
import { Button } from '../Button/Button';

export default function BannerSec({banner,h4,p,button}) {

    const bannerUrl = `/images/${banner}.jpg`
    return  (
        <section className='uk-banner-picture'> 
            <img src={bannerUrl} alt={h4}></img>
            <div className='tour-box'>
                <h4 className='tour-box-title'>
                    <span className='tour-box-pretitle'>{h4}<br></br></span>
                    
                    <span className='tour-box-text'>{p}</span>
                </h4>
                <p className='tour-box-space'> 
                <Button 
                className='btns'
                buttonStyle='btn--outline'
                buttonSize='btn--large'
                >
                   {button}
                </Button></p>
               
            </div>
        </section>
    )
}
