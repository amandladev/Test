import React from 'react';
import Navbar from './components/Navbar/Navbar';
import Home from './pages/Home'
import { Route, Router } from "wouter";
import './App.css';

function App() {
 
  
  return (
    <>
    <Navbar></Navbar> 
    <Route path='/' exact component={Home}/>
    
  </>
  );
}

export default App;
