import React from 'react'
import Kitchen from '../components/Kitchen/Kitchen'
import '../App.css'
import Designph from '../components/DesignPh/DesignPh'
import BannerSec from '../components/BannerSec/BannerSec'
import WhiteBanner from '../components/WhiteBanner/WhiteBanner'
import Footer from '../components/Footer/Footer'

function Home () {
    return (
        <>
            <Kitchen></Kitchen>
            <Designph></Designph>
            <BannerSec  banner= {"headquarter"}
            h4= {"Virtual Tour"} 
            p= {"Headquarter company showroom"}
            button={"Inizia il tour virtuale"}>
                
            </BannerSec>
            <WhiteBanner></WhiteBanner>
            <BannerSec  banner= {"euromobil"}
            h4= {"Store Project"} 
            p= {"Milano fragship store"}
            button={"Scopri di pi"}>
                
            </BannerSec>
            <Footer></Footer>
        </>
    )
}
export default Home