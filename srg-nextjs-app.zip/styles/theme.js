export const breakpoints = {
    mobile: '520px'
  }
  
  /* https://coolors.co/palette/2b2d42-8d99ae-f8f32b-ffffff-000000 */ 
  export const colors = {
    hardblue: '#2B2D42',
    lightblue: '#8D99AE',
    yellow: '#F8F32B',
    white: '#FFFFFF',
    black: '#000000'
  } 