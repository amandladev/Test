{/* 
import { useEffect, useState } from 'react'
import { useWeb3React } from '@web3-react/core'
import useContract from '../../hooks/useContract'
import NftImage from '../NftImages'

export default function ContractInt(){
   
    let arrayNftsCount
    const contractData = useContract()
    const {account} = useWeb3React()
    const [balance, setBbalance] = useState(0)
    const [totalMinted, setTotalMinted] = useState(0)

    
    const getbalanceOf = async () => {  
        return contractData.methods
        .balanceOf(account)
        .call()
        .then((balance) => {
			return balance    
		})    
    }
    const fetchBalance = () => {
     getbalanceOf().then(balance =>{
            setBbalance(balance)
        }).catch(err => {
            console.log(err)
        })
    }
    const getCount = async () => {  
        const count = await contractData.methods.totalSupply().call()
        console.log(parseInt(count))
        setTotalMinted(parseInt(count))   
    }

    useEffect(() => {
        getCount() 
    }, [getCount])

    return (
        <>
      
          <p>in Stock:   {1000-totalMinted}/1000</p>
      <ul className="slider">

            {arrayNftsCount= new Array(totalMinted)
            .fill()
            .map((_, i) => (
                <NftImage tokenId={i} getCount={getCount} />          
            ))}
      </ul>
         
              <style jsx>{`
             ul{
              display: flex;
              list-style-type: disc;
              flex-wrap: wrap;
              gap:10px
             }

                `}</style>
        </>
    )
  }

*/}