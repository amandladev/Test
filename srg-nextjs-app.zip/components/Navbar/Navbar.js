import { colors } from "../../styles/theme";

export default function Navbar(){
    return (
        <>
            <section>
            <div className="home">
            <div className="social">
                <a href="https://twitter.com/karafuruNFT">
                
                    <img src="/twitter.png" alt="twitter" className="socialicon twitter"/>
                </a>
                <a href="https://www.instagram.com/karafuruNFT/">
                    <img src="/instragram.png" alt="instagram" className="socialicon iinstagram"/>
                </a>
                <a href="https://discord.com/invite/karafuru">
                    <img src="/discord.png" alt="discord" className="socialicon ddiscord"/>
                </a>
            </div>
            <div className="outer-content"> 
                <div className="inner-content"> 
                    <img src="/banner.jpg" alt="Image" className="img-fluid"/>
                </div>
            </div>
        </div>
        </section>
            <style jsx>
                {`
                .home{
                    position: relative;
                    display: block;
                }
                img{
                    vertical-align: middle;
                }
                a{
                    text-decoration: none;
                    background-color: transparent;
                    margin-right: 5px;

                }
                .socialicon{
                    width: 3.5rem;
                    height: 3.5rem;
                }

                .iinstagram{
                    transform: rotate(353deg);
                    width: 3.3rem;
                    height: 3.3rem;
                }
                .ddiscord{
                    transform: rotate(353deg);
                }

              
                .social{
                    z-index: 1;
                    display: flex;
                    justify-content: space-between;
                    position: absolute;
                    right: 0;
                    top: 1rem;
                    width: 11rem;
                    padding-right: 17%;
                    
                }
            
                
                `}
            </style>
        </>
    )
}