export default function Footer(){
    return (
        <>
        <section>
            <div className="footer">
                <div className="imageratio">
                    <div className="outer-content">
                        <div className="contentinner">
                            <img src="/banner2.jpg" alt="Image" className="img-fluid" />
                        </div>
                    </div>
                </div>
                <div className="home-footer">
                    <a href="https://twitter.com/karafuruNFT">
                        <img src="/twitter.png" alt="twitter" className="img-fluid footericon tttwitter" />
                    </a>
                    <a href="https://www.instagram.com/karafuruNFT/">
                        <img src="/instragram.png" alt="instagram" className="img-fluid footericon iiinstagram" />
                    </a>
                    <a href="https://discord.com/invite/karafuru">
                        <img src="/discord.png" alt="discord" className="img-fluid footericon dddiscord" />
                    </a>
                    
                </div>
                <div className="bg-colorful">
                    <div className="bg-footer1">
                        
                        <img src="/footerxl.png"  className="img-fluid black-img-footer"  alt="Image" />
                    </div>
                    <div className="bg-footer2">
                        
                        <img src="/footerxl.png"  className="img-fluid pink-img-footer"  alt="Image" />
                    </div>
                  
                </div>
            </div>
        </section>
        <style jsx>
            {`
            .footer{
    font-family: Chunky Rose;
    position: relative;
    margin-top: 0;
    
   
}
.imageratio{
    position: relative;
    z-index: 0;
}

.contentinner img{
    overflow: hidden;
}
.footericon{
   
    position: absolute;
    
    z-index: 7;
}
.dddiscord{
    right: 4rem; 
    transform: rotate(-7.75deg);
    bottom: 5.5rem;
    height: 5rem;
    width: 5rem;
    transition:  0.5s;
}
.tttwitter{  
    right: 10rem; 
    bottom: 7rem;
    height: 4.5rem;
    width: 4.5rem;
    transition:  0.5s;
}
.iiinstagram{
    right: 7rem; 
    bottom: 10.5rem;
    height: 4.5rem;
    width: 4.5rem;
    transition:  0.5s;
}
.dddiscord:hover{
    transform: scale(1.2);
}
.tttwitter:hover{
    transform: scale(1.2);
}
.iiinstagram:hover{
    transform: scale(1.2);
}
.home-footer{
    
    z-index: 8;
}
.bg-colorful{
    position: relative;
}
.bg-footer1{
    position: absolute;
    bottom: -35px;
    z-index: 4;
}

.bg-footer2{
    position: absolute;
    bottom: 0;
    z-index: 3;
}
.black-img-footer{
    filter: brightness(0);
    
    z-index: 10;
}
.pink-img-footer{
    z-index: 8;
  }
            `}
        </style>
        </>
    )
}