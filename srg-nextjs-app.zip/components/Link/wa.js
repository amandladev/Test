import Link from 'next/link'

export default function WaConnector({children}) {
  return (
   
        <Link href="/walletconnector" replace>
            {children}
        </Link>
    
  )
}