import { useRouter } from 'next/router'
import { useWeb3React } from '@web3-react/core'
import useContract from '../../hooks/useContract'


const NftCard = ({ image, name, tokenId, owner}) => {
    const contractData = useContract()
    const {active, account} = useWeb3React()
    const router = useRouter()

    {/*const handleClick = (e) => {
        e.preventDefault()
        router.replace(`/detail?tokenId=${tokenId}`)
      }*/}
  
    return (
        <>
            <div className="container">
                <article className="material-card" >
                    <div className="material-h2">
                        <p> Owner by: {owner.substring(0,6)}...{owner.substring(owner.length - 4)}</p>
                    <a className='a-details-nft' onClick={ () => (router.push(`/detail?tokenId=${tokenId}`))}> {name}</a>
                       
                    </div>
                    <div className="mc-content">
                        <div className="img-container">
                            <img className="img-responsive" src={image} alt={name}/>
                        </div>
                    </div>
                </article>
            </div>
        
        <style jsx> 
            {`
            .a-details-nft{
                cursor:pointer;
                color: rgb(255, 0, 234);
                
                font-size: 1rem;
            }
            .a-details-nft:hover{
                color: aqua;
            }

            .img-minted{
                width:100px;
                height:100px;
            }
            .container{
                position: relative;
                padding-right: 15px;
                padding-left: 15px;
                width: 270px;
                margin-top: 10px;
                margin-bottom:10px;
            }
            .material-card{
                position: relative;
                height: 0;
                padding-bottom: calc(100% - 16px);
                margin-bottom: 6.6em;
            }
            .material-card .material-h2{
                position: absolute;
                top: calc(100% - 16px);
                left: 0;
                width: 100%;
                padding: 10px 16px;
                color: #fff;
                font-size: 1.4em;
                line-height: 1.6em;
                margin: 0;
                z-index: 10;
                background-color: #272623;
            }
            .material-h2::before{
                content: '';
                position: absolute;
                left: 0;
                top: -16px;
                width: 0;
                border: 8px solid;
                border-top-color: transparent;
                border-right-color: #7d7b74;
                border-bottom-color: #7d7b74;
                border-left-color: transparent;
            }

            .material-card .mc-content{
                position: absolute;
                right: 0;
                top: 0;
                bottom: 16px;
                left: 16px;
            }
            .material-card .img-container{
                overflow: hidden;
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                z-index: 3;
            }
            .img-responsive{
                display: block;
                max-width: 100%;
                height: auto;
            }
`}
        </style>
        </>
    )
}
export default NftCard